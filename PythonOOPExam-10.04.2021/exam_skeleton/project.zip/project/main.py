from project.aquarium.freshwater_aquarium import FreshwaterAquarium
from project.controller import Controller

controller = Controller()

fwa = FreshwaterAquarium("fresh")
controller.add_aquarium("FreshwaterAquarium", "top aquarium")
controller.add_aquarium("SaltwaterAquarium", "second aquarium")
controller.add_decoration("Ornament")
controller.insert_decoration("top aquarium", "Ornament")
controller.add_fish("top aquarium", "FreshwaterFish", "gosho", "hrrr", 10)
print(controller.report())


